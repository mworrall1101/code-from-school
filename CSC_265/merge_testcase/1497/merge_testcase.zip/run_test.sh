#This shell script uses merge.py to generate the example in the
#assignment specification
python3 merge.py "au_id" fname.csv last_name.csv phone.csv
