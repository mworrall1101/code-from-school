python3 merge.py "MessageID" universities.csv classes.csv professor.csv messages.csv
