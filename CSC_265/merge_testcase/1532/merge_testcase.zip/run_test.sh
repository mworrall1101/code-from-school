#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py Name file1.csv file2.csv file3.csv file4.csv
