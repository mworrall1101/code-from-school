python3 merge.py number sheet1.txt sheet2.txt sheet3.txt sheet4.txt
