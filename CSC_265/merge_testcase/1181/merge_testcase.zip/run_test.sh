python3 merge.py col1 test1.csv test2.csv test3.csv
