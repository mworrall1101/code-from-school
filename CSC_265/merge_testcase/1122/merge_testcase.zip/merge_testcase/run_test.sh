#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py "ID" employee1.csv employee2.csv employee3.csv
