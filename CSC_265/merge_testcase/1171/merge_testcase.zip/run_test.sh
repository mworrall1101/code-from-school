#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py "Number" NBA_player.csv player_career.csv player_career_2.csv
