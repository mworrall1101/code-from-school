#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py "ID" pets.csv grades1.csv grades2.csv
