python3 merge.py "Subject" Average_grades.csv Number_of_students.csv
