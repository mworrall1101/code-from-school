#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py "Student Number" course.csv major.csv year.csv gpa.csv
