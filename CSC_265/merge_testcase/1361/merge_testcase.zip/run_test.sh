python3 ./merge.py "Country" ./Average\ Disposable\ Income.csv ./Population.csv ./Murder\ Rate.csv
