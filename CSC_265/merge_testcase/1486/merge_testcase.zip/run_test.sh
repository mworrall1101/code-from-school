#seng265
#assignment3
python3 merge.py "Date" 265_a1_location.csv 265_a2_weather.csv event.csv
