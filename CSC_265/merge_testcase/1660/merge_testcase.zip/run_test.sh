#This shell script uses merge.py to generate the example in the 
#assignment specification
#Thank you to the following:
#https://support.spatialkey.com/spatialkey-sample-csv-data/
#who supplied this data.
python3 merge.py "commission_id" city_street.csv location.csv bednbath.csv price.csv 
