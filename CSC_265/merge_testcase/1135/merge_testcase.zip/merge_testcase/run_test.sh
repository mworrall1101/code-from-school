#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py "Student Number" 265_a2_grades.csv student_names.csv 265_a1_grades.csv
