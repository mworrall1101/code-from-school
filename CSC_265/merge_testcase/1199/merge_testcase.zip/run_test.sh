python3 merge.py "Character" MidSpace1.csv MidSpace2.csv
echo
python3 merge.py "Numbers" BlankTest1.csv BlankTest2.csv
echo
python3 merge.py "Ztop" AlphName1.csv AlphName2.csv
echo
python3 merge.py "Major" FirstName.csv MiddleName.csv LastName.csv
