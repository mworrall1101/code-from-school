python3 merge.py "Name" 1.csv 2.csv 3.csv 4.csv
