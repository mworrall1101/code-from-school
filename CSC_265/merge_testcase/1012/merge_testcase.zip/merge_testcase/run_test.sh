python3 merge.py fruit fruits1.csv fruits2.csv fruits3.csv fruits4.txt
