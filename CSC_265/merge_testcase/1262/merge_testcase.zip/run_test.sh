#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py 'Player Name' basketball.csv basketball_assists.csv basketball_rebounds.csv basketball_other.csv basketball_team.csv basketball_status.csv
