#!/bin/bash
python3 merge.py keyCol file.txt file2.txt
