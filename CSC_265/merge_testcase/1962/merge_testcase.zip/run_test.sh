python3 merge.py "user id" test0.csv test1.csv test2.csv test3.csv
