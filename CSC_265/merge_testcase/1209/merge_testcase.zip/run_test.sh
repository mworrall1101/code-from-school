#Shell Script
python3 merge.py "Students" People.csv People_Like_Dogs.csv People_have_moods.csv
