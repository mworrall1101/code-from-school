python3 merge.py "food" recipes.txt foodCalories.txt foodCost.txt oneCol.csv 
