python3 merge.py Film feature_films.csv critical_reception.csv box_office.csv
