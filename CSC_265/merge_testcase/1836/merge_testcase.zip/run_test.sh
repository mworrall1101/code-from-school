#Shell Script
python3 merge.py 'Vehicle Number' File1.csv File2.csv File3.csv
