python3 merge.py "lowercase" test1.txt test2.txt test3.txt
