python3 merge.py id names.csv addresses.csv contact.csv birthdays.csv eyes.csv occupations.csv
