#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py "Full_Name" test_table1.csv test_table2.csv test_table3.csv
