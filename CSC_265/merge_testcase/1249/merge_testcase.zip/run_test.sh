python3 merge.py "Name" file1.csv file2.csv file3.csv file4.csv
