python3 merge.py "Name" file1.csv file2.csv file3.csv file4.csv file5.csv file6.csv file7.csv
