python3 merge.py 'Name' lcs_players.csv player_stats.csv player_stats2.csv
