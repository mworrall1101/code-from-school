python3 merge.py V test1.csv test2.csv test3.csv 
