#!/bin/bash
python3 merge.py "Student Number" student_names.csv 265_a1_grades.csv 265_a2_grades.csv 
