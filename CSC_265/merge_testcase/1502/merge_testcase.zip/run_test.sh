python3 merge.py ID threat.csv favourites.csv names.csv
