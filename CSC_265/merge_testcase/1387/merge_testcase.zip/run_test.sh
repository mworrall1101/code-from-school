#This shell script uses merge.py to generate the example in the 
#assignment specification
python3 merge.py "key column" tester1.csv tester2.csv tester3.csv
